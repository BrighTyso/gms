<?php  
session_start()
require_once("../api/conn.php");


$userid=$_GET['userid'];


?>