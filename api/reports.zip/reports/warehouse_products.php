<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type:application/json");
header("Access-Control-Allow-Origin-Methods:POST");
header("Access-Control-Allow-Headers:Access-Control-Allow-Headers,Content-Type,Access-Control-Allow-Origin-Methods,Authorization,X-Requested-With");

require_once("../conn.php");



$data = json_decode(file_get_contents("php://input"));


$userid=$data->userid;
$seasonid=$data->seasonid;
$description=$data->description;

$data1=array();
// get grower locations

if ($description!="") {
  
$sql = "Select store.id,products.id as productid,store.name,store.location,products.name as product_name,store_items.quantity,products.units,store_items.created_at from store join store_items on store.id=store_items.storeid join products on products.id=store_items.productid where products.name='$description' or store.name='$description'";
$result = $conn->query($sql);
 
 if ($result->num_rows > 0) {
   // output data of each row
   while($row = $result->fetch_assoc()) {
    // echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
    $temp=array("productid"=>$row["productid"],"id"=>$row["id"],"name"=>$row["name"],"location"=>$row["location"],"product_name"=>$row["product_name"],"quantity"=>$row["quantity"],"units"=>$row["units"],"created_at"=>$row["created_at"]);
    array_push($data1,$temp);
    
   }
 }


}else{


$sql = "Select store.id,products.id as productid,store.name,store.location,products.name as product_name,store_items.quantity,products.units,store_items.created_at from store join store_items on store.id=store_items.storeid join products on products.id=store_items.productid ";
$result = $conn->query($sql);
 
 if ($result->num_rows > 0) {
   // output data of each row
   while($row = $result->fetch_assoc()) {
    // echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
    $temp=array("productid"=>$row["productid"],"id"=>$row["id"],"name"=>$row["name"],"location"=>$row["location"],"product_name"=>$row["product_name"],"quantity"=>$row["quantity"],"units"=>$row["units"],"created_at"=>$row["created_at"]);
    array_push($data1,$temp);
    
   }
 }

}







 echo json_encode($data1);


?>


